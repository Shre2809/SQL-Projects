--SQL Advance Case Study


--Q1--BEGIN 
Select distinct([state]) from  (select * , datepart(Year , [date]) as YEAR from fact_transactions as T
Where datepart(Year , [date]) >= 2005) as z
inner join  DIM_LOCATION  as L
on z.IDLocation = L.IDLocation


--Q1--END

--Q2--BEGIN
create view galaxy  as
select T.IDModel , IDLocation , quantity , Model_name  from fact_transactions AS T
left join  dim_model as M
on T.IDModel = M.IDModel
where Model_name like 'galaxy%'

select top 1[state] , sum(quantity) as Total from (select QUANTITY , country , [state] from galaxy as G
left join dim_location as L
ON G.IDLocation = L.IDLocation
where country = 'US') TB
group by [state]
order by Total desc



--Q2--END

--Q3--BEGIN      
create view Model_transac as
select t.IDModel , Idlocation , Model_name  from fact_transactions as T
inner join DIM_MODEL as M
on t.IDModel= M.IDModel


select Model_name , zipcode , [state] , count(*) as Num_transactions from Model_transac as G
left join DIM_LOCATION as L
ON G.IDLOCATION = L.IDLOCATION
group by Model_name , zipcode , [state]


--Q3--END

--Q4--BEGIN
select top 1 Model_name , unit_price from fact_transactions as F
left join dim_model as M
ON f.idmodel = m.idmodel
order by unit_price


--Q4--END

--Q5--BEGIN
create view top_manufctr as
select top 5 z.idmanufacturer ,  manufacturer_name , sum(quantity) as Total_Quantity from (select f.idmodel , model_name , idmanufacturer  ,quantity from fact_transactions AS F
left join dim_model as M
ON F.IDMODEL = M.IDMODEL) as Z
left join dim_manufacturer as D
on z.idmanufacturer = d.idmanufacturer
group by  z.idmanufacturer , manufacturer_name
order by Total_Quantity  desc

select model_name , avg(totalprice) as AVERAGE_PRICE from fact_transactions AS B
inner join
(select idmodel , model_name , unit_price , manufacturer_name  from dim_model as M
inner join top_manufctr  as Y
on m.idmanufacturer = y.idmanufacturer) as A
ON B.IDMODEL=A.IDMODEL
GROUP BY MODEL_NAME 
ORDER BY  AVERAGE_PRICE desc

--Q5--END

--Q6--BEGIN
create view cust_spent as
select CUSTOMER_NAME , TOTALPRICE  , datepart(year , date) as [Year] from fact_transactions as F
inner join DIM_CUSTOMER AS C
ON F.IDCUSTOMER = C.IDCUSTOMER
WHERE datepart(year , date) = 2009

select customer_name , avg(totalprice) as Average_amount from cust_spent
group by customer_name
having avg(totalprice) > 500
order by Average_amount desc

--Q6--END
	
--Q7--BEGIN  
CREATE VIEW MODEL_2008 AS
select top 5 model_name , sum(quantity) as total from ( select m.model_name , totalprice , quantity , datepart(year , date) as [Year]  from fact_transactions as t
left join dim_model as m
on t.idmodel = m.idmodel
where datepart(year , date) in ( 2008 )) as z
group by model_name
ORDER BY total desc

CREATE VIEW MODEL_2009 AS
select top 5 model_name , sum(quantity) as total from ( select m.model_name , totalprice , quantity , datepart(year , date) as [Year]  from fact_transactions as t
left join dim_model as m
on t.idmodel = m.idmodel
where datepart(year , date) in ( 2009 )) as z
group by model_name
order by total desc

create view model_2010 as
select top 5 model_name , sum(quantity) as total from ( select m.model_name , totalprice , quantity , datepart(year , date) as [Year]  from fact_transactions as t
left join dim_model as m
on t.idmodel = m.idmodel
where datepart(year , date) in ( 2010 )) as z
group by model_name
order by total desc



select model_name from Model_2008
intersect
select model_name from model_2009
intersect
select model_name from model_2010


--Q7--END	
--Q8--BEGIN
create view sales_2009 as
select top 1 * from (select top 2 manufacturer_name , sum(totalprice) as sales from (select d.manufacturer_name , t.totalprice , datepart(year , t.date) as Year from fact_transactions as T
left join dim_model as M
on t.idmodel = m.idmodel
inner join DIM_MANUFACTURER as D
on m.idmanufacturer=d.idmanufacturer
where datepart(year , t.date) = 2009) as z
group by manufacturer_name
order by sales desc) AS Y
order by sales

create view sales_2010 as
select top 1 * from (select top 2 manufacturer_name , sum(totalprice) as sales from (select d.manufacturer_name , t.totalprice , datepart(year , t.date) as Year from fact_transactions as T
left join dim_model as M
on t.idmodel = m.idmodel
inner join DIM_MANUFACTURER as D
on m.idmanufacturer=d.idmanufacturer
where datepart(year , t.date) = 2010) as z
group by manufacturer_name
order by sales desc) AS Y
order by sales


select 'Top_2nd_sales_2009' as Top_2nd_sales_Yearly , * from sales_2009
union all
select 'Top_2nd_sales_2010' , * from sales_2010

--Q8--END
--Q9--BEGIN

select manufacturer_name from (select distinct(manufacturer_name) , datepart(year , t.date) as Year  from fact_transactions AS T
left join dim_model as M
ON T.IDMODEL = M.IDMODEL
INNER JOIN dim_manufacturer as P
on m.idmanufacturer = p.idmanufacturer
where datepart(year , t.date) = 2010) as z
where manufacturer_name not in (select manufacturer_name from (select distinct(manufacturer_name) , datepart(year , t.date) as Year  from fact_transactions AS T
left join dim_model as M
ON T.IDMODEL = M.IDMODEL
INNER JOIN dim_manufacturer as P
on m.idmanufacturer = p.idmanufacturer
where datepart(year , t.date) = 2009) as Y)

--Q9--END

--Q10--BEGIN
create view shry as
 select D.Customer_Name , avg(totalprice) as AVG_SPEND , AVG(QUANTITY) AS AVG_QTY  , YEAR(DATE) AS YR , SUM(TOTALPRICE) AS Total_spend , 
  ROW_NUMBER() over(partition by d.customer_name order by year(t.date) desc) as Sno
 from (select top 10 idcustomer , sum(totalprice) spend  from FACT_TRANSACTIONS
group by IDCustomer 
order by spend desc) as Z
left join fact_transactions as t
on z.idcustomer = t.idcustomer
left join DIM_CUSTOMER AS D
on z.IDCustomer=d.IDCustomer
GROUP BY D.Customer_Name , YEAR(DATE)


select a.Customer_Name , a.AVG_SPEND , a.AVG_QTY , a.YR , 
concat((round((cast(a.total_spend - b.total_spend as float)/b.Total_spend) , 3)*100) , '%') as '%_change'   from shry as a
left join shry as b
on a.Sno+1=b.Sno and a.Customer_Name = b.Customer_Name

--Q10--END